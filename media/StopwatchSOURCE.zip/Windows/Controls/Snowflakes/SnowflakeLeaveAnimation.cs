﻿namespace WpfSnowfall.Models;

public enum SnowflakeAnimation
{
    None,
    Fade
}
