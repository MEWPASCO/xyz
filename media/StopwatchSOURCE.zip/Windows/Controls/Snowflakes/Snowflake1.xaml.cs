﻿using System.Windows.Controls;

namespace WpfSnowfall.Snowflakes;

/// <summary>
/// Logica di interazione per Snowflake1.xaml
/// </summary>
public partial class Snowflake1 : UserControl
{
    public Snowflake1()
    {
        InitializeComponent();
    }
}
